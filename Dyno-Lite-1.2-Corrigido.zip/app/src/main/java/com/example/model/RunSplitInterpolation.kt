package com.example.model

import kotlin.math.abs
import kotlin.math.sqrt

/** Utilities for locating a speed or distance crossing between two sparse GPS fixes. */
object RunSplitInterpolation {

  fun speedCrossingTimestampNs(
    previousTimestampNs: Long,
    currentTimestampNs: Long,
    previousSpeedKmh: Float,
    currentSpeedKmh: Float,
    targetSpeedKmh: Float
  ): Long? {
    if (currentTimestampNs <= previousTimestampNs ||
      previousSpeedKmh >= targetSpeedKmh ||
      currentSpeedKmh < targetSpeedKmh ||
      currentSpeedKmh <= previousSpeedKmh
    ) return null

    val fraction = ((targetSpeedKmh - previousSpeedKmh) /
      (currentSpeedKmh - previousSpeedKmh)).coerceIn(0f, 1f)
    return previousTimestampNs + ((currentTimestampNs - previousTimestampNs) * fraction).toLong()
  }

  fun distanceCrossingTimestampNs(
    previousTimestampNs: Long,
    currentTimestampNs: Long,
    previousDistanceM: Float,
    currentDistanceM: Float,
    previousSpeedMps: Float,
    currentSpeedMps: Float,
    targetDistanceM: Float
  ): Long? {
    if (currentTimestampNs <= previousTimestampNs ||
      previousDistanceM >= targetDistanceM ||
      currentDistanceM < targetDistanceM
    ) return null

    val intervalSec = (currentTimestampNs - previousTimestampNs) / 1_000_000_000.0
    val remainingM = (targetDistanceM - previousDistanceM).toDouble()
    val v0 = previousSpeedMps.coerceAtLeast(0f).toDouble()
    val acceleration = (currentSpeedMps - previousSpeedMps) / intervalSec

    val crossingSec = if (abs(acceleration) < 1e-6) {
      if (v0 <= 1e-6) return null else remainingM / v0
    } else {
      val discriminant = v0 * v0 + 2.0 * acceleration * remainingM
      if (discriminant < 0.0) return null
      val rootA = (-v0 + sqrt(discriminant)) / acceleration
      val rootB = (-v0 - sqrt(discriminant)) / acceleration
      listOf(rootA, rootB).firstOrNull { it in 0.0..intervalSec }
        ?: return null
    }

    val fraction = (crossingSec / intervalSec).coerceIn(0.0, 1.0)
    return previousTimestampNs + ((currentTimestampNs - previousTimestampNs) * fraction).toLong()
  }
}
