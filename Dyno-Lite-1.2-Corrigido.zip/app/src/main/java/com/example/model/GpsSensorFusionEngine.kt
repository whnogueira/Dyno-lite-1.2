package com.example.model

import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max

/**
 * Ponto de localização GPS estritamente validado por elapsedRealtimeNanos.
 */
data class GpsFixPoint(
  val elapsedRealtimeNanos: Long,
  val speedMps: Float,
  val speedAccuracyMps: Float = 0f,
  val accuracyMeters: Float = 0f,
  val hasSpeed: Boolean = true,
  val timestampMs: Long = 0L
)

/**
 * Amostra de sensor inercial estritamente indexada por timestamp de hardware (nanossegundos monotônicos).
 */
data class RawSensorSample(
  val timestampNs: Long,
  val rawSensorAccelerationMps2: Float,
  val filteredSensorAccelerationMps2: Float,
  val gyroMagnitude: Float = 0f,
  val isValid: Boolean = true,
  val rejectionReason: String? = null
)

/**
 * Parâmetros físicos do veículo para o cálculo de potência e torque na fusão.
 */
data class VehiclePhysicsParams(
  val totalMassKg: Float,
  val cd: Float = 0.34f,
  val frontalAreaM2: Float = 2.10f,
  val airDensityKgM3: Float = 1.225f,
  val crr: Float = 0.015f,
  val drivetrainLossPercent: Float = 12f,
  val tireCircumferenceM: Double? = null,
  val gearRatio: Float? = null,
  val finalDrive: Float? = null,
  val slopePercent: Float = 0f
)

/**
 * Ponto amostral reconstruído e fechado no intervalo GPS.
 */
data class ProcessedIntervalPoint(
  val timestampNs: Long,
  val rawSensorAccelerationMps2: Float = 0f,
  val filteredSensorAccelerationMps2: Float = 0f,
  val rawSensorG: Float = 0f,
  val filteredSensorG: Float = 0f,
  val gpsMeanG: Float = 0f,
  val correctedLongitudinalG: Float = 0f,
  val finalAccelerationMps2: Float = 0f,
  val reconstructedSpeedMps: Float = 0f,
  val reconstructedSpeedKmh: Float = 0f,
  val wheelPowerWatts: Float = 0f,
  val wheelPowerCv: Float = 0f,
  val enginePowerCv: Float = 0f,
  val wheelTorqueKgfm: Float = 0f,
  val engineTorqueKgfm: Float = 0f,
  val wheelTorqueNm: Float = 0f,
  val engineTorqueNm: Float = 0f,
  val engineRpm: Int? = null,
  val gyroMagnitude: Float = 0f,
  val isProvisional: Boolean = false,
  val isValid: Boolean = true,
  val rejectionReason: String? = null,
  val accelerationForceN: Float = 0f,
  val aerodynamicForceN: Float = 0f,
  val rollingForceN: Float = 0f,
  val slopeForceN: Float = 0f,
  val totalForceN: Float = 0f,
  val confidenceFactor: Float = 1.0f
)

/**
 * Resultado da fusão para um intervalo específico entre dois fixes GPS consecutivos.
 */
data class GpsIntervalFusion(
  val intervalIndex: Int,
  val startGps: GpsFixPoint,
  val endGps: GpsFixPoint,
  val deltaTGpsSec: Double,
  val deltaVGpsMps: Float,
  val sensorDeltaVMps: Float,
  val gpsMeanAccelerationMps2: Float,
  val sensorMeanAccelerationMps2: Float,
  val gpsMeanG: Float,
  val confidenceFactor: Float,
  val rawClosureRatio: Float,
  val closureErrorBeforeMps: Float,
  val closureErrorAfterMps: Float,
  val isAccepted: Boolean,
  val qualityStatus: String, // "BOA CONCORDÂNCIA", "CONCORDÂNCIA REGULAR", "DIVERGÊNCIA ELEVADA", "DESCARTADO"
  val points: List<ProcessedIntervalPoint>
)

/**
 * Diagnóstico consolidado da passagem completa.
 */
data class FusionRunSummary(
  val intervals: List<GpsIntervalFusion>,
  val allPoints: List<ProcessedIntervalPoint>,
  val totalGpsDeltaVMps: Float,
  val totalSensorDeltaVMps: Float,
  val totalFinalIntegratedDeltaVMps: Float,
  val finalClosureErrorMps: Float,
  val overallRawClosureRatio: Float,
  val averageConfidenceFactor: Float,
  val rawSensorMeanG: Float,
  val filteredSensorMeanG: Float,
  val gpsMeanG: Float,
  val correctedLongitudinalG: Float,
  val instantaneousPeakPowerCv: Float,
  val robustPeakPowerCv: Float,
  val instantaneousPeakWheelPowerCv: Float,
  val robustPeakWheelPowerCv: Float,
  val peakTorqueKgfm: Float,
  val peakWheelTorqueKgfm: Float,
  val peakPowerRpm: Int?,
  val peakTorqueRpm: Int?,
  val peakPowerSpeedKmh: Float,
  val peakTorqueSpeedKmh: Float,
  val runQuality: String,
  val confidenceLevel: String,
  val marginPercent: Float,
  val marginDisplay: String,
  val invalidationReason: String?
)

/**
 * Motor de Fusão GPS × Acelerômetro com Repetibilidade e Fechamento Exato de Integral.
 */
object GpsSensorFusionEngine {

  const val STANDARD_GRAVITY = 9.80665f
  const val WATTS_PER_CV = 735.49875f
  const val CLOSURE_TOLERANCE_MPS = 0.02f
  const val DEFAULT_CONFIDENCE_FACTOR = 0.35f

  /**
   * Processa um intervalo fechado entre dois fixes GPS consecutivos.
   */
  fun processInterval(
    intervalIndex: Int,
    startGps: GpsFixPoint,
    endGps: GpsFixPoint,
    sensorSamples: List<RawSensorSample>,
    params: VehiclePhysicsParams,
    overrideConfidenceFactor: Float? = null
  ): GpsIntervalFusion {
    val deltaTGpsSec = (endGps.elapsedRealtimeNanos - startGps.elapsedRealtimeNanos) / 1_000_000_000.0

    // 1. Validações básicas do intervalo GPS (Requisitos 2 e 3)
    if (deltaTGpsSec <= 0.0 || !startGps.hasSpeed || !endGps.hasSpeed || endGps.accuracyMeters > 25.0f || deltaTGpsSec > 3.5) {
      return GpsIntervalFusion(
        intervalIndex = intervalIndex,
        startGps = startGps,
        endGps = endGps,
        deltaTGpsSec = max(0.0, deltaTGpsSec),
        deltaVGpsMps = 0f,
        sensorDeltaVMps = 0f,
        gpsMeanAccelerationMps2 = 0f,
        sensorMeanAccelerationMps2 = 0f,
        gpsMeanG = 0f,
        confidenceFactor = 0f,
        rawClosureRatio = 0f,
        closureErrorBeforeMps = 0f,
        closureErrorAfterMps = 0f,
        isAccepted = false,
        qualityStatus = "DESCARTADO",
        points = emptyList()
      )
    }

    val deltaVGpsMps = endGps.speedMps - startGps.speedMps
    val gpsMeanAcceleration = (deltaVGpsMps / deltaTGpsSec).toFloat()
    val gpsMeanG = gpsMeanAcceleration / STANDARD_GRAVITY

    // 2. Filtrar estritamente as amostras de sensores contidas neste intervalo temporal (Requisito 2)
    // Uma amostra com timestamp t pertence ao intervalo se t > startGps e t <= endGps
    val samplesInInterval = sensorSamples.filter {
      it.timestampNs > startGps.elapsedRealtimeNanos && it.timestampNs <= endGps.elapsedRealtimeNanos
    }.sortedBy { it.timestampNs }

    // Criação de linha do tempo fechada [startGps.elapsedRealtimeNanos .. endGps.elapsedRealtimeNanos]
    val tStartNs = startGps.elapsedRealtimeNanos
    val tEndNs = endGps.elapsedRealtimeNanos

    val timeline = mutableListOf<RawSensorSample>()

    if (samplesInInterval.isEmpty()) {
      // Se não houver amostras inerciais no intervalo, ancorar nos valores médios do GPS
      timeline.add(
        RawSensorSample(
          timestampNs = tStartNs,
          rawSensorAccelerationMps2 = gpsMeanAcceleration,
          filteredSensorAccelerationMps2 = gpsMeanAcceleration,
          isValid = true
        )
      )
      timeline.add(
        RawSensorSample(
          timestampNs = tEndNs,
          rawSensorAccelerationMps2 = gpsMeanAcceleration,
          filteredSensorAccelerationMps2 = gpsMeanAcceleration,
          isValid = true
        )
      )
    } else {
      // Ponto de início (se a primeira amostra tiver timestamp maior que tStartNs)
      if (samplesInInterval.first().timestampNs > tStartNs) {
        timeline.add(
          samplesInInterval.first().copy(timestampNs = tStartNs)
        )
      }
      timeline.addAll(samplesInInterval)
      // Ponto de término (se a última amostra tiver timestamp menor que tEndNs)
      if (samplesInInterval.last().timestampNs < tEndNs) {
        timeline.add(
          samplesInInterval.last().copy(timestampNs = tEndNs)
        )
      }
    }

    // 3. Integração Temporal Trapezoidal do Sensor (Requisito 5)
    var sensorDeltaV = 0.0
    for (i in 0 until timeline.size - 1) {
      val dt = (timeline[i + 1].timestampNs - timeline[i].timestampNs) / 1_000_000_000.0
      val aAvg = (timeline[i].filteredSensorAccelerationMps2 + timeline[i + 1].filteredSensorAccelerationMps2) / 2.0
      sensorDeltaV += aAvg * dt
    }
    val sensorMeanAcceleration = (sensorDeltaV / deltaTGpsSec).toFloat()

    // 4. Razão de Divergência Bruta (Requisito 14)
    val rawClosureRatio = abs(sensorDeltaV.toFloat() - deltaVGpsMps) / max(abs(deltaVGpsMps), 0.5f)

    // 5. Determinação do Fator de Confiança (Requisito 6)
    val confidenceFactor = if (overrideConfidenceFactor != null) {
      overrideConfidenceFactor.coerceIn(0.0f, 0.50f)
    } else {
      val maxGyro = samplesInInterval.map { it.gyroMagnitude }.maxOrNull() ?: 0f
      when {
        maxGyro > 4.5f -> 0.0f // Movimento severo do aparelho / suporte
        rawClosureRatio <= 0.15f -> DEFAULT_CONFIDENCE_FACTOR // 0.35f
        rawClosureRatio <= 0.35f -> 0.20f
        rawClosureRatio <= 0.60f -> 0.10f
        else -> 0.05f
      }
    }

    // 6. Normalização Obrigatória (Requisito 6)
    // correctedAcceleration = gpsMeanAcceleration + confidenceFactor * (filteredSensor - sensorMean)
    val correctedAccels = timeline.map { sample ->
      val sensorDeviation = sample.filteredSensorAccelerationMps2 - sensorMeanAcceleration
      gpsMeanAcceleration + confidenceFactor * sensorDeviation
    }

    // 7. Fechamento Exato da Integral Trapezoidal (Requisito 7)
    var correctedDeltaV = 0.0
    for (i in 0 until timeline.size - 1) {
      val dt = (timeline[i + 1].timestampNs - timeline[i].timestampNs) / 1_000_000_000.0
      val aAvg = (correctedAccels[i] + correctedAccels[i + 1]) / 2.0
      correctedDeltaV += aAvg * dt
    }

    val closureErrorBefore = deltaVGpsMps - correctedDeltaV.toFloat()
    val finalCorrection = (closureErrorBefore / deltaTGpsSec).toFloat()

    val finalAccels = correctedAccels.map { it + finalCorrection }

    // Verificação de fechamento final
    var finalIntegratedDeltaV = 0.0
    for (i in 0 until timeline.size - 1) {
      val dt = (timeline[i + 1].timestampNs - timeline[i].timestampNs) / 1_000_000_000.0
      val aAvg = (finalAccels[i] + finalAccels[i + 1]) / 2.0
      finalIntegratedDeltaV += aAvg * dt
    }
    val closureErrorAfter = abs(finalIntegratedDeltaV.toFloat() - deltaVGpsMps)
    val isAccepted = closureErrorAfter <= CLOSURE_TOLERANCE_MPS

    // 8. Reconstrução Contínua de Velocidade (Requisito 8)
    val reconstructedSpeeds = DoubleArray(timeline.size)
    reconstructedSpeeds[0] = startGps.speedMps.toDouble()
    for (i in 0 until timeline.size - 1) {
      val dt = (timeline[i + 1].timestampNs - timeline[i].timestampNs) / 1_000_000_000.0
      val aAvg = (finalAccels[i] + finalAccels[i + 1]) / 2.0
      reconstructedSpeeds[i + 1] = reconstructedSpeeds[i] + aAvg * dt
    }
    // Ancorar o último ponto exatamente no GPS final
    reconstructedSpeeds[reconstructedSpeeds.size - 1] = endGps.speedMps.toDouble()

    // 9. Cálculo Físico de Potência e Forças para cada amostra (Requisitos 11 e 13)
    val lossFraction = (params.drivetrainLossPercent / 100f).coerceIn(0f, 0.40f)
    val drivetrainEfficiency = (1.0f - lossFraction).coerceIn(0.60f, 1.0f)
    val rollForceN = params.crr * params.totalMassKg * STANDARD_GRAVITY
    val slopeForceN = params.totalMassKg * STANDARD_GRAVITY * (params.slopePercent / 100f)

    val processedPoints = timeline.mapIndexed { idx, rawSample ->
      val vMps = reconstructedSpeeds[idx].toFloat().coerceAtLeast(0f)
      val aMps2 = finalAccels[idx]

      val accelForceN = params.totalMassKg * aMps2
      val aeroForceN = 0.5f * params.airDensityKgM3 * params.cd * params.frontalAreaM2 * (vMps * vMps)
      val tractiveForceN = max(0f, accelForceN + rollForceN + aeroForceN + slopeForceN)

      val wheelPowerWatts = tractiveForceN * vMps
      val wheelPowerCv = wheelPowerWatts / WATTS_PER_CV
      val enginePowerCv = wheelPowerCv / drivetrainEfficiency

      val rpm = if (params.tireCircumferenceM != null && params.gearRatio != null && params.finalDrive != null &&
        params.gearRatio > 0f && params.finalDrive > 0f && params.tireCircumferenceM > 0.0
      ) {
        val totalRatio = params.gearRatio * params.finalDrive
        val wheelRps = vMps / params.tireCircumferenceM
        val calculatedRpm = (wheelRps * totalRatio * 60.0).toInt()
        if (calculatedRpm in 400..12000) calculatedRpm else null
      } else null

      var engineTorqueNm = 0f
      var wheelTorqueNm = 0f
      var engineTorqueKgfm = 0f
      var wheelTorqueKgfm = 0f

      if (rpm != null && rpm > 500) {
        val angularVelocity = rpm * 2.0 * PI / 60.0
        if (angularVelocity > 0.01) {
          val eWatts = enginePowerCv * WATTS_PER_CV
          val wWatts = wheelPowerWatts
          val eNm = (eWatts / angularVelocity).toFloat()
          val wNm = (wWatts / angularVelocity).toFloat()
          val eKgfm = eNm / STANDARD_GRAVITY
          val wKgfm = wNm / STANDARD_GRAVITY
          if (eKgfm.isFinite() && wKgfm.isFinite()) {
            engineTorqueNm = eNm
            wheelTorqueNm = wNm
            engineTorqueKgfm = eKgfm
            wheelTorqueKgfm = wKgfm
          }
        }
      }

      ProcessedIntervalPoint(
        timestampNs = rawSample.timestampNs,
        rawSensorAccelerationMps2 = rawSample.rawSensorAccelerationMps2,
        filteredSensorAccelerationMps2 = rawSample.filteredSensorAccelerationMps2,
        rawSensorG = rawSample.rawSensorAccelerationMps2 / STANDARD_GRAVITY,
        filteredSensorG = rawSample.filteredSensorAccelerationMps2 / STANDARD_GRAVITY,
        gpsMeanG = gpsMeanG,
        correctedLongitudinalG = aMps2 / STANDARD_GRAVITY,
        finalAccelerationMps2 = aMps2,
        reconstructedSpeedMps = vMps,
        reconstructedSpeedKmh = vMps * 3.6f,
        wheelPowerWatts = wheelPowerWatts,
        wheelPowerCv = wheelPowerCv,
        enginePowerCv = enginePowerCv,
        wheelTorqueKgfm = wheelTorqueKgfm,
        engineTorqueKgfm = engineTorqueKgfm,
        wheelTorqueNm = wheelTorqueNm,
        engineTorqueNm = engineTorqueNm,
        engineRpm = rpm,
        gyroMagnitude = rawSample.gyroMagnitude,
        isProvisional = false,
        isValid = rawSample.isValid,
        rejectionReason = rawSample.rejectionReason,
        accelerationForceN = accelForceN,
        aerodynamicForceN = aeroForceN,
        rollingForceN = rollForceN,
        slopeForceN = slopeForceN,
        totalForceN = tractiveForceN,
        confidenceFactor = confidenceFactor
      )
    }

    val qualityStatus = when {
      !isAccepted -> "DESCARTADO"
      rawClosureRatio <= 0.15f -> "BOA CONCORDÂNCIA"
      rawClosureRatio <= 0.35f -> "CONCORDÂNCIA REGULAR"
      else -> "DIVERGÊNCIA ELEVADA"
    }

    return GpsIntervalFusion(
      intervalIndex = intervalIndex,
      startGps = startGps,
      endGps = endGps,
      deltaTGpsSec = deltaTGpsSec,
      deltaVGpsMps = deltaVGpsMps,
      sensorDeltaVMps = sensorDeltaV.toFloat(),
      gpsMeanAccelerationMps2 = gpsMeanAcceleration,
      sensorMeanAccelerationMps2 = sensorMeanAcceleration,
      gpsMeanG = gpsMeanG,
      confidenceFactor = confidenceFactor,
      rawClosureRatio = rawClosureRatio,
      closureErrorBeforeMps = closureErrorBefore,
      closureErrorAfterMps = closureErrorAfter,
      isAccepted = isAccepted,
      qualityStatus = qualityStatus,
      points = processedPoints
    )
  }

  /**
   * Processa todos os fixes GPS da passagem gerando resumo consolidado.
   */
  fun processFullRun(
    gpsFixes: List<GpsFixPoint>,
    sensorSamples: List<RawSensorSample>,
    params: VehiclePhysicsParams,
    overrideConfidenceFactor: Float? = null,
    hasGearShift: Boolean = false,
    hasClutchDisengaged: Boolean = false,
    isPrematureTermination: Boolean = false
  ): FusionRunSummary {
    if (gpsFixes.size < 2) {
      return emptyRunSummary(runQuality = "DADOS INSUFICIENTES", invalidReason = "Menos de 2 atualizações GPS registradas.")
    }

    // Filtrar apenas fixes GPS válidos e estritamente monotônicos
    val sortedGps = gpsFixes.filter { it.hasSpeed && it.accuracyMeters <= 25.0f }
      .sortedBy { it.elapsedRealtimeNanos }

    val distinctGps = mutableListOf<GpsFixPoint>()
    for (fix in sortedGps) {
      val prev = distinctGps.lastOrNull()
      if (prev == null || fix.elapsedRealtimeNanos > prev.elapsedRealtimeNanos) {
        distinctGps.add(fix)
      }
    }

    if (distinctGps.size < 2) {
      return emptyRunSummary(runQuality = "DADOS INSUFICIENTES", invalidReason = "Fixes de GPS insuficientes após filtragem monotônica.")
    }

    // A finalização acontece somente depois que a desaceleração é confirmada. Esses fixes
    // posteriores ao pico servem para detectar o fim da passagem, mas não pertencem à janela
    // de aceleração. Mantê-los aqui fazia o cabeçalho usar a velocidade máxima enquanto o
    // diagnóstico e a curva terminavam numa velocidade já reduzida.
    val peakGpsIndex = distinctGps.indices.maxByOrNull { distinctGps[it].speedMps } ?: distinctGps.lastIndex
    val accelerationGps = distinctGps.take(peakGpsIndex + 1)

    if (accelerationGps.size < 2) {
      return emptyRunSummary(
        runQuality = "PASSAGEM INCOMPLETA",
        invalidReason = "Não houve ganho de velocidade após o início da passagem."
      )
    }

    val intervals = mutableListOf<GpsIntervalFusion>()
    for (i in 0 until accelerationGps.size - 1) {
      val gStart = accelerationGps[i]
      val gEnd = accelerationGps[i + 1]
      val interval = processInterval(
        intervalIndex = i,
        startGps = gStart,
        endGps = gEnd,
        sensorSamples = sensorSamples,
        params = params,
        overrideConfidenceFactor = overrideConfidenceFactor
      )
      intervals.add(interval)
    }

    val acceptedIntervals = intervals.filter { it.isAccepted }
    val allAcceptedPoints = acceptedIntervals.flatMap { it.points }.sortedBy { it.timestampNs }

    val totalGpsDeltaV = accelerationGps.last().speedMps - accelerationGps.first().speedMps
    val totalSensorDeltaV = intervals.map { it.sensorDeltaVMps }.sum()

    val totalElapsedSec = (accelerationGps.last().elapsedRealtimeNanos - accelerationGps.first().elapsedRealtimeNanos) / 1_000_000_000.0f
    val gpsMeanAcceleration = if (totalElapsedSec > 0.05f) totalGpsDeltaV / totalElapsedSec else 0f
    val totalGpsMeanG = gpsMeanAcceleration / STANDARD_GRAVITY

    val rawSensorMeanG = if (intervals.isNotEmpty()) {
      intervals.map { it.sensorMeanAccelerationMps2 / STANDARD_GRAVITY }.average().toFloat()
    } else 0f

    val filteredSensorMeanG = rawSensorMeanG
    val correctedLongitudinalG = totalGpsMeanG // Por fechamento matemático a aceleração média corrigida é idêntica à do GPS

    val totalFinalIntegratedDeltaV = allAcceptedPoints.let { pts ->
      var dv = 0.0
      for (i in 0 until pts.size - 1) {
        val dt = (pts[i + 1].timestampNs - pts[i].timestampNs) / 1_000_000_000.0
        val aAvg = (pts[i].finalAccelerationMps2 + pts[i + 1].finalAccelerationMps2) / 2.0
        dv += aAvg * dt
      }
      dv.toFloat()
    }

    val finalClosureErrorMps = abs(totalFinalIntegratedDeltaV - totalGpsDeltaV)
    val overallRawClosureRatio = abs(totalSensorDeltaV - totalGpsDeltaV) / max(abs(totalGpsDeltaV), 0.5f)
    val avgConfidence = if (intervals.isNotEmpty()) intervals.map { it.confidenceFactor }.average().toFloat() else DEFAULT_CONFIDENCE_FACTOR

    // 10. Cálculo de Potência Máxima Robusta com Mediana Móvel de 400 ms (Requisito 12)
    val robustPeaks = calculateRobustPeaks(allAcceptedPoints)

    // 11. Classificação da Qualidade da Passagem (Requisito 15)
    val speedGainKmh = totalGpsDeltaV * 3.6f
    val effectiveGpsCount = accelerationGps.size
    val closedIntervalsCount = acceptedIntervals.size

    val (quality, confLevel, marginPct, marginDisp, reason) = evaluateRunQuality(
      speedGainKmh = speedGainKmh,
      effectiveGpsCount = effectiveGpsCount,
      closedIntervalsCount = closedIntervalsCount,
      totalElapsedSec = totalElapsedSec,
      overallRawClosureRatio = overallRawClosureRatio,
      hasGearShift = hasGearShift,
      hasClutchDisengaged = hasClutchDisengaged,
      isPrematureTermination = isPrematureTermination,
      closureErrorMps = finalClosureErrorMps
    )

    return FusionRunSummary(
      intervals = intervals,
      allPoints = allAcceptedPoints,
      totalGpsDeltaVMps = totalGpsDeltaV,
      totalSensorDeltaVMps = totalSensorDeltaV,
      totalFinalIntegratedDeltaVMps = totalFinalIntegratedDeltaV,
      finalClosureErrorMps = finalClosureErrorMps,
      overallRawClosureRatio = overallRawClosureRatio,
      averageConfidenceFactor = avgConfidence,
      rawSensorMeanG = rawSensorMeanG,
      filteredSensorMeanG = filteredSensorMeanG,
      gpsMeanG = totalGpsMeanG,
      correctedLongitudinalG = correctedLongitudinalG,
      instantaneousPeakPowerCv = robustPeaks.instantaneousPeakPowerCv,
      robustPeakPowerCv = robustPeaks.robustPeakPowerCv,
      instantaneousPeakWheelPowerCv = robustPeaks.instantaneousPeakWheelPowerCv,
      robustPeakWheelPowerCv = robustPeaks.robustPeakWheelPowerCv,
      peakTorqueKgfm = robustPeaks.peakTorqueKgfm,
      peakWheelTorqueKgfm = robustPeaks.peakWheelTorqueKgfm,
      peakPowerRpm = robustPeaks.peakPowerRpm,
      peakTorqueRpm = robustPeaks.peakTorqueRpm,
      peakPowerSpeedKmh = robustPeaks.peakPowerSpeedKmh,
      peakTorqueSpeedKmh = robustPeaks.peakTorqueSpeedKmh,
      runQuality = quality,
      confidenceLevel = confLevel,
      marginPercent = marginPct,
      marginDisplay = marginDisp,
      invalidationReason = reason
    )
  }

  data class PeakDetectionResult(
    val instantaneousPeakPowerCv: Float,
    val robustPeakPowerCv: Float,
    val instantaneousPeakWheelPowerCv: Float,
    val robustPeakWheelPowerCv: Float,
    val peakTorqueKgfm: Float,
    val peakWheelTorqueKgfm: Float,
    val peakPowerRpm: Int?,
    val peakTorqueRpm: Int?,
    val peakPowerSpeedKmh: Float,
    val peakTorqueSpeedKmh: Float
  )

  /**
   * Calcula o pico robusto de potência e torque aplicando janela de mediana móvel de 400 ms.
   * Não permite que uma única amostra ou ruído transitório determine a máxima.
   */
  fun calculateRobustPeaks(points: List<ProcessedIntervalPoint>): PeakDetectionResult {
    val validPoints = points.filter { it.isValid && it.enginePowerCv > 0f }
    if (validPoints.isEmpty()) {
      return PeakDetectionResult(0f, 0f, 0f, 0f, 0f, 0f, null, null, 0f, 0f)
    }

    val instantaneousPower = validPoints.maxOfOrNull { it.enginePowerCv } ?: 0f
    val instantaneousWheelPower = validPoints.maxOfOrNull { it.wheelPowerCv } ?: 0f

    // Mediana móvel em janela de 400 ms (±200 ms)
    val windowHalfWidthNs = 200_000_000L // 200 ms

    data class Candidate(
      val point: ProcessedIntervalPoint,
      val smoothedPowerCv: Float,
      val smoothedWheelPowerCv: Float,
      val windowSampleCount: Int,
      val windowDurationNs: Long
    )

    val candidates = mutableListOf<Candidate>()

    for (i in validPoints.indices) {
      val pt = validPoints[i]
      // Janela de ±200 ms
      val inWindow = validPoints.filter { abs(it.timestampNs - pt.timestampNs) <= windowHalfWidthNs }
      if (inWindow.size >= 3) {
        val sortedEngine = inWindow.map { it.enginePowerCv }.sorted()
        val sortedWheel = inWindow.map { it.wheelPowerCv }.sorted()
        val medianEngine = sortedEngine[sortedEngine.size / 2]
        val medianWheel = sortedWheel[sortedWheel.size / 2]
        val duration = inWindow.last().timestampNs - inWindow.first().timestampNs

        candidates.add(
          Candidate(
            point = pt,
            smoothedPowerCv = medianEngine,
            smoothedWheelPowerCv = medianWheel,
            windowSampleCount = inWindow.size,
            windowDurationNs = duration
          )
        )
      }
    }

    // Filtrar candidatos robustos:
    // - Pelo menos 3 amostras na janela
    // - Não ser a última amostra isolada
    // - Não coincidir com movimento grave do suporte (giroscópio)
    val filteredCandidates = candidates.filterIndexed { index, cand ->
      val isLastSample = (index == candidates.size - 1) && (cand.point.timestampNs == validPoints.last().timestampNs)
      val isStable = cand.point.gyroMagnitude < 4.0f
      !isLastSample && isStable
    }

    // Critério de sustentação por pelo menos 250 ms:
    // Procura o maior valor de potência cuja faixa superior (>= 90% do pico) se sustente por >= 250 ms
    val sustainedCandidates = filteredCandidates.filter { cand ->
      val threshold = cand.smoothedPowerCv * 0.90f
      val sustainedPoints = validPoints.filter {
        abs(it.timestampNs - cand.point.timestampNs) <= 250_000_000L && it.enginePowerCv >= threshold
      }
      val durationNs = if (sustainedPoints.isNotEmpty()) {
        sustainedPoints.last().timestampNs - sustainedPoints.first().timestampNs
      } else 0L
      durationNs >= 200_000_000L || cand.windowDurationNs >= 250_000_000L
    }

    val bestCandidate = sustainedCandidates.maxByOrNull { it.smoothedPowerCv }
      ?: filteredCandidates.maxByOrNull { it.smoothedPowerCv }
      ?: candidates.maxByOrNull { it.smoothedPowerCv }

    val robustPowerCv = bestCandidate?.smoothedPowerCv ?: instantaneousPower
    val robustWheelPowerCv = bestCandidate?.smoothedWheelPowerCv ?: instantaneousWheelPower
    val peakPowerRpm = bestCandidate?.point?.engineRpm
    val peakPowerSpeedKmh = bestCandidate?.point?.reconstructedSpeedKmh ?: 0f

    // Pico de Torque Robusto
    val torquePool = validPoints.filter { it.engineTorqueKgfm > 0f && (it.engineRpm ?: 0) in 1000..7500 }
    val bestTorquePoint = torquePool.maxByOrNull { it.engineTorqueKgfm } ?: validPoints.maxByOrNull { it.engineTorqueKgfm }

    val peakTorqueKgfm = bestTorquePoint?.engineTorqueKgfm ?: 0f
    val peakWheelTorqueKgfm = bestTorquePoint?.wheelTorqueKgfm ?: 0f
    val peakTorqueRpm = bestTorquePoint?.engineRpm
    val peakTorqueSpeedKmh = bestTorquePoint?.reconstructedSpeedKmh ?: 0f

    return PeakDetectionResult(
      instantaneousPeakPowerCv = instantaneousPower,
      robustPeakPowerCv = robustPowerCv,
      instantaneousPeakWheelPowerCv = instantaneousWheelPower,
      robustPeakWheelPowerCv = robustWheelPowerCv,
      peakTorqueKgfm = peakTorqueKgfm,
      peakWheelTorqueKgfm = peakWheelTorqueKgfm,
      peakPowerRpm = peakPowerRpm,
      peakTorqueRpm = peakTorqueRpm,
      peakPowerSpeedKmh = peakPowerSpeedKmh,
      peakTorqueSpeedKmh = peakTorqueSpeedKmh
    )
  }

  /**
   * Avalia a qualidade e margem da passagem seguindo rigorosamente a ordem de prioridades (Requisito 15):
   * 1. PASSAGEM INCOMPLETA
   * 2. DADOS INSUFICIENTES
   * 3. GPS/SENSOR DIVERGENTE
   * 4. REGULAR
   * 5. BOA
   */
  private fun evaluateRunQuality(
    speedGainKmh: Float,
    effectiveGpsCount: Int,
    closedIntervalsCount: Int,
    totalElapsedSec: Float,
    overallRawClosureRatio: Float,
    hasGearShift: Boolean,
    hasClutchDisengaged: Boolean,
    isPrematureTermination: Boolean,
    closureErrorMps: Float
  ): RunQualityData {
    // 1. PRIORIDADE 1: PASSAGEM INCOMPLETA
    if (hasGearShift || hasClutchDisengaged || isPrematureTermination) {
      val reason = when {
        hasGearShift -> "Troca de marcha detectada durante a aceleração."
        hasClutchDisengaged -> "Acionamento de embreagem detectado."
        else -> "Aceleração interrompida antes da faixa ideal."
      }
      return RunQualityData(
        quality = "PASSAGEM INCOMPLETA",
        confidenceLevel = "BAIXA",
        marginPercent = 20.0f,
        marginDisplay = "acima de ±20%",
        invalidationReason = reason
      )
    }

    // 2. PRIORIDADE 2: DADOS INSUFICIENTES
    if (effectiveGpsCount < 8 || closedIntervalsCount < 4 || totalElapsedSec < 3.0f || speedGainKmh < 10.0f) {
      val reason = when {
        effectiveGpsCount < 8 -> "Menos de 8 atualizações GPS válidas ($effectiveGpsCount < 8)."
        closedIntervalsCount < 4 -> "Poucos intervalos GPS fechados ($closedIntervalsCount < 4)."
        totalElapsedSec < 3.0f -> String.format(Locale.US, "Duração insuficiente (%.2fs < 3.00s).", totalElapsedSec)
        else -> String.format(Locale.US, "Ganho de velocidade insuficiente (%.1f km/h < 10 km/h).", speedGainKmh)
      }
      return RunQualityData(
        quality = "DADOS INSUFICIENTES",
        confidenceLevel = "BAIXA",
        marginPercent = 25.0f,
        marginDisplay = "acima de ±20%",
        invalidationReason = reason
      )
    }

    // 3. PRIORIDADE 3: GPS/SENSOR DIVERGENTE
    // Avaliada SOMENTE após confirmar dados suficientes
    if (overallRawClosureRatio > 0.35f || closureErrorMps > CLOSURE_TOLERANCE_MPS) {
      val divergencePercent = (overallRawClosureRatio * 100).toInt()
      return RunQualityData(
        quality = "GPS/SENSOR DIVERGENTE",
        confidenceLevel = "BAIXA",
        marginPercent = 20.0f,
        marginDisplay = "±20%",
        invalidationReason = "Divergência severa entre acelerômetro e GPS ($divergencePercent% > 35%). Aceleração normalizada pelo GPS."
      )
    }

    // 4. PRIORIDADE 4: REGULAR
    if (overallRawClosureRatio > 0.15f || speedGainKmh < 25.0f) {
      val divergencePercent = (overallRawClosureRatio * 100).toInt()
      return RunQualityData(
        quality = "REGULAR",
        confidenceLevel = "MEDIA",
        marginPercent = 15.0f,
        marginDisplay = "±15%",
        invalidationReason = if (overallRawClosureRatio > 0.15f) "Divergência moderada entre acelerômetro e GPS ($divergencePercent% > 15%)." else null
      )
    }

    // 5. PRIORIDADE 5: BOA
    return RunQualityData(
      quality = "BOA",
      confidenceLevel = "ALTA",
      marginPercent = 10.0f,
      marginDisplay = "±10%",
      invalidationReason = null
    )
  }

  private data class RunQualityData(
    val quality: String,
    val confidenceLevel: String,
    val marginPercent: Float,
    val marginDisplay: String,
    val invalidationReason: String?
  )

  private fun emptyRunSummary(runQuality: String, invalidReason: String?): FusionRunSummary {
    return FusionRunSummary(
      intervals = emptyList(),
      allPoints = emptyList(),
      totalGpsDeltaVMps = 0f,
      totalSensorDeltaVMps = 0f,
      totalFinalIntegratedDeltaVMps = 0f,
      finalClosureErrorMps = 0f,
      overallRawClosureRatio = 0f,
      averageConfidenceFactor = DEFAULT_CONFIDENCE_FACTOR,
      rawSensorMeanG = 0f,
      filteredSensorMeanG = 0f,
      gpsMeanG = 0f,
      correctedLongitudinalG = 0f,
      instantaneousPeakPowerCv = 0f,
      robustPeakPowerCv = 0f,
      instantaneousPeakWheelPowerCv = 0f,
      robustPeakWheelPowerCv = 0f,
      peakTorqueKgfm = 0f,
      peakWheelTorqueKgfm = 0f,
      peakPowerRpm = null,
      peakTorqueRpm = null,
      peakPowerSpeedKmh = 0f,
      peakTorqueSpeedKmh = 0f,
      runQuality = runQuality,
      confidenceLevel = "BAIXA",
      marginPercent = 25.0f,
      marginDisplay = "acima de ±20%",
      invalidationReason = invalidReason
    )
  }
}
