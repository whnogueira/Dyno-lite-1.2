package com.example

import com.example.model.GpsFixPoint
import com.example.model.GpsSensorFusionEngine
import com.example.model.ProcessedIntervalPoint
import com.example.model.RawSensorSample
import com.example.model.VehiclePhysicsParams
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class GpsSensorFusionEngineTest {

  private val standardParams = VehiclePhysicsParams(
    totalMassKg = 1344f,
    cd = 0.32f,
    frontalAreaM2 = 2.15f,
    airDensityKgM3 = 1.225f,
    crr = 0.015f,
    drivetrainLossPercent = 12f,
    tireCircumferenceM = 1.98,
    gearRatio = 2.14f,
    finalDrive = 4.10f,
    slopePercent = 0f
  )

  @Test
  fun test01_integralClosureWithinThreshold() {
    // Requisito: A integral da aceleração corrigida seja igual ao deltaV GPS (tolerância <= 0.02 m/s)
    val startNs = 1_000_000_000L
    val endNs = 2_000_000_000L // 1 segundo
    val gpsStart = GpsFixPoint(elapsedRealtimeNanos = startNs, speedMps = 10.0f, hasSpeed = true)
    val gpsEnd = GpsFixPoint(elapsedRealtimeNanos = endNs, speedMps = 11.0f, hasSpeed = true) // deltaV = 1.0 m/s

    // Sensor com ruído/bias: medindo 1.6 m/s² constante (deltaV bruto seria 1.6 m/s)
    val sensorSamples = (0..20).map { i ->
      val t = startNs + i * 50_000_000L
      RawSensorSample(
        timestampNs = t,
        rawSensorAccelerationMps2 = 1.6f,
        filteredSensorAccelerationMps2 = 1.6f,
        isValid = true
      )
    }

    val interval = GpsSensorFusionEngine.processInterval(
      intervalIndex = 0,
      startGps = gpsStart,
      endGps = gpsEnd,
      sensorSamples = sensorSamples,
      params = standardParams
    )

    assertEquals(1.0f, interval.deltaVGpsMps, 0.001f)
    assertTrue("Erro de fechamento residual deve ser <= 0.02 m/s, obtido: ${interval.closureErrorAfterMps}", interval.closureErrorAfterMps <= 0.02f)
    assertTrue("Intervalo deve ser aceito", interval.isAccepted)
  }

  @Test
  fun test02_pureSensorGainZeroWhenGpsZero() {
    // Requisito: O acelerômetro não pode criar ganho total de velocidade se o GPS indicar zero
    val startNs = 1_000_000_000L
    val endNs = 2_000_000_000L
    val gpsStart = GpsFixPoint(elapsedRealtimeNanos = startNs, speedMps = 15.0f, hasSpeed = true)
    val gpsEnd = GpsFixPoint(elapsedRealtimeNanos = endNs, speedMps = 15.0f, hasSpeed = true) // deltaV = 0.0 m/s

    // Celular inclinado ou vibrando gerando 2.0 m/s²
    val sensorSamples = (0..20).map { i ->
      val t = startNs + i * 50_000_000L
      RawSensorSample(
        timestampNs = t,
        rawSensorAccelerationMps2 = 2.0f,
        filteredSensorAccelerationMps2 = 2.0f,
        isValid = true
      )
    }

    val interval = GpsSensorFusionEngine.processInterval(
      intervalIndex = 0,
      startGps = gpsStart,
      endGps = gpsEnd,
      sensorSamples = sensorSamples,
      params = standardParams
    )

    assertEquals(0.0f, interval.deltaVGpsMps, 0.001f)
    assertTrue("Erro residual de fechamento deve ser <= 0.02 m/s", interval.closureErrorAfterMps <= 0.02f)
    // Velocidade reconstruída ao final deve ser 15.0 m/s (ganho líquido nulo)
    val finalSpeed = interval.points.lastOrNull()?.reconstructedSpeedMps ?: 0f
    assertEquals(15.0f, finalSpeed, 0.02f)
  }

  @Test
  fun test03_confidenceFactorBehaviorHighAgreement() {
    // Requisito: Fator de confiança alto (~0.85) quando sensor concorda com GPS
    val startNs = 1_000_000_000L
    val endNs = 2_000_000_000L
    val gpsStart = GpsFixPoint(elapsedRealtimeNanos = startNs, speedMps = 10.0f, hasSpeed = true)
    val gpsEnd = GpsFixPoint(elapsedRealtimeNanos = endNs, speedMps = 11.0f, hasSpeed = true) // deltaV = 1.0 m/s

    // Sensor medindo 1.02 m/s² (concordância quase perfeita: 2% de diferença)
    val sensorSamples = (0..20).map { i ->
      RawSensorSample(
        timestampNs = startNs + i * 50_000_000L,
        rawSensorAccelerationMps2 = 1.02f,
        filteredSensorAccelerationMps2 = 1.02f,
        isValid = true
      )
    }

    val interval = GpsSensorFusionEngine.processInterval(
      intervalIndex = 0,
      startGps = gpsStart,
      endGps = gpsEnd,
      sensorSamples = sensorSamples,
      params = standardParams
    )

    assertEquals(0.35f, interval.confidenceFactor, 0.01f)
  }

  @Test
  fun test04_confidenceFactorBehaviorDivergence() {
    // Requisito: Fator de confiança cai para o mínimo (~0.35) em caso de divergência severa
    val startNs = 1_000_000_000L
    val endNs = 2_000_000_000L
    val gpsStart = GpsFixPoint(elapsedRealtimeNanos = startNs, speedMps = 10.0f, hasSpeed = true)
    val gpsEnd = GpsFixPoint(elapsedRealtimeNanos = endNs, speedMps = 11.0f, hasSpeed = true) // deltaV = 1.0 m/s

    // Sensor medindo 2.5 m/s² (150% acima do GPS)
    val sensorSamples = (0..20).map { i ->
      RawSensorSample(
        timestampNs = startNs + i * 50_000_000L,
        rawSensorAccelerationMps2 = 2.5f,
        filteredSensorAccelerationMps2 = 2.5f,
        isValid = true
      )
    }

    val interval = GpsSensorFusionEngine.processInterval(
      intervalIndex = 0,
      startGps = gpsStart,
      endGps = gpsEnd,
      sensorSamples = sensorSamples,
      params = standardParams
    )

    assertTrue("Fator de confiança deve cair para o patamar reduzido (<= 0.40), obtido: ${interval.confidenceFactor}", interval.confidenceFactor <= 0.40f)
  }

  @Test
  fun test05_closureCorrectionProportionalToGpsFrequency() {
    // Requisito: Fechamento exato e eliminação da deriva acumulada em cada fix
    val startNs = 1_000_000_000L
    val endNs = 2_000_000_000L
    val gpsStart = GpsFixPoint(elapsedRealtimeNanos = startNs, speedMps = 10.0f, hasSpeed = true)
    val gpsEnd = GpsFixPoint(elapsedRealtimeNanos = endNs, speedMps = 11.0f, hasSpeed = true)

    val sensorSamples = (0..20).map { i ->
      val accel = 1.0f + (i / 20f) * 1.0f
      RawSensorSample(
        timestampNs = startNs + i * 50_000_000L,
        rawSensorAccelerationMps2 = accel,
        filteredSensorAccelerationMps2 = accel,
        isValid = true
      )
    }

    val interval = GpsSensorFusionEngine.processInterval(
      intervalIndex = 0,
      startGps = gpsStart,
      endGps = gpsEnd,
      sensorSamples = sensorSamples,
      params = standardParams
    )

    assertTrue(interval.closureErrorAfterMps <= 0.02f)
    assertTrue(interval.isAccepted)
  }

  @Test
  fun test06_transientNoiseRejection() {
    // Requisito: Picos transientes no acelerômetro não alteram o ganho total
    val startNs = 1_000_000_000L
    val endNs = 2_000_000_000L
    val gpsStart = GpsFixPoint(elapsedRealtimeNanos = startNs, speedMps = 10.0f, hasSpeed = true)
    val gpsEnd = GpsFixPoint(elapsedRealtimeNanos = endNs, speedMps = 11.0f, hasSpeed = true)

    // Acelerômetro com pico de 10 m/s² durante 50 ms (ex: bump na pista)
    val sensorSamples = (0..20).map { i ->
      val accel = if (i == 10) 10.0f else 1.0f
      RawSensorSample(
        timestampNs = startNs + i * 50_000_000L,
        rawSensorAccelerationMps2 = accel,
        filteredSensorAccelerationMps2 = accel,
        isValid = true
      )
    }

    val interval = GpsSensorFusionEngine.processInterval(
      intervalIndex = 0,
      startGps = gpsStart,
      endGps = gpsEnd,
      sensorSamples = sensorSamples,
      params = standardParams
    )

    // O ganho final do intervalo ainda deve fechar com o GPS de 1.0 m/s
    assertTrue(interval.closureErrorAfterMps <= 0.02f)
    val finalSpeed = interval.points.lastOrNull()?.reconstructedSpeedMps ?: 0f
    assertEquals(11.0f, finalSpeed, 0.02f)
  }

  @Test
  fun test07_monotonicTimestampsOnly() {
    // Requisito: Amostras inerciais fora do intervalo estrito [t_gps_k, t_gps_k+1] não podem ser atribuídas ao intervalo
    val startNs = 2_000_000_000L
    val endNs = 3_000_000_000L
    val gpsStart = GpsFixPoint(elapsedRealtimeNanos = startNs, speedMps = 10.0f, hasSpeed = true)
    val gpsEnd = GpsFixPoint(elapsedRealtimeNanos = endNs, speedMps = 11.0f, hasSpeed = true)

    val sampleBefore = RawSensorSample(timestampNs = 1_500_000_000L, rawSensorAccelerationMps2 = 5f, filteredSensorAccelerationMps2 = 5f)
    val sampleInside = RawSensorSample(timestampNs = 2_500_000_000L, rawSensorAccelerationMps2 = 1f, filteredSensorAccelerationMps2 = 1f)
    val sampleAfter = RawSensorSample(timestampNs = 3_500_000_000L, rawSensorAccelerationMps2 = 5f, filteredSensorAccelerationMps2 = 5f)

    val interval = GpsSensorFusionEngine.processInterval(
      intervalIndex = 0,
      startGps = gpsStart,
      endGps = gpsEnd,
      sensorSamples = listOf(sampleBefore, sampleInside, sampleAfter),
      params = standardParams
    )

    // Amostras antes e depois não são incluídas nos pontos do intervalo
    assertTrue(interval.points.all { it.timestampNs in startNs..endNs })
  }

  @Test
  fun test08_robustPeakPowerWithMovingMedian() {
    // Requisito 12: Potência robusta com filtro de mediana móvel de 400ms elimina pico isolado
    val points = (0..20).map { i ->
      val isSpike = (i == 10)
      ProcessedIntervalPoint(
        timestampNs = 1_000_000_000L + i * 50_000_000L,
        reconstructedSpeedMps = 15.0f,
        reconstructedSpeedKmh = 54.0f,
        finalAccelerationMps2 = 1.0f,
        correctedLongitudinalG = 0.102f,
        enginePowerCv = if (isSpike) 250.0f else 100.0f, // Spike isolado de 250 cv
        wheelPowerCv = if (isSpike) 220.0f else 88.0f,
        engineTorqueKgfm = 15.0f,
        wheelTorqueKgfm = 13.0f,
        isValid = true
      )
    }

    val peaks = GpsSensorFusionEngine.calculateRobustPeaks(points)
    // A mediana móvel deve descartar o spike de 250 cv e reportar ~100 cv
    assertEquals(100.0, peaks.robustPeakPowerCv.toDouble(), 2.0)
  }

  @Test
  fun test09_robustPeakPowerSustained() {
    // Requisito 12: Potência real sustentada por mais de 250-400ms é preservada
    val points = (0..30).map { i ->
      // Curva com patamar sustentado de 125 cv entre os índices 10 e 20 (500 ms)
      val power = when (i) {
        in 10..20 -> 125.0f
        else -> 90.0f
      }
      ProcessedIntervalPoint(
        timestampNs = 1_000_000_000L + i * 50_000_000L,
        reconstructedSpeedMps = 15.0f,
        reconstructedSpeedKmh = 54.0f,
        finalAccelerationMps2 = 1.2f,
        correctedLongitudinalG = 0.12f,
        enginePowerCv = power,
        wheelPowerCv = power * 0.88f,
        engineTorqueKgfm = 16.0f,
        wheelTorqueKgfm = 14.0f,
        isValid = true
      )
    }

    val peaks = GpsSensorFusionEngine.calculateRobustPeaks(points)
    assertEquals(125.0, peaks.robustPeakPowerCv.toDouble(), 1.0)
  }

  @Test
  fun test10_wheelPowerDrivetrainEfficiencyApplied() {
    // Requisito 11: Potência na roda e motor respeitam drivetrainLossPercent
    val points = (0..10).map { i ->
      ProcessedIntervalPoint(
        timestampNs = 1_000_000_000L + i * 50_000_000L,
        reconstructedSpeedMps = 15.0f,
        reconstructedSpeedKmh = 54.0f,
        finalAccelerationMps2 = 1.0f,
        correctedLongitudinalG = 0.10f,
        enginePowerCv = 100.0f,
        wheelPowerCv = 88.0f, // 12% loss
        engineTorqueKgfm = 15.0f,
        wheelTorqueKgfm = 13.2f,
        isValid = true
      )
    }

    val peaks = GpsSensorFusionEngine.calculateRobustPeaks(points)

    assertTrue(peaks.robustPeakPowerCv > peaks.robustPeakWheelPowerCv)
    assertEquals(88.0, peaks.robustPeakWheelPowerCv.toDouble(), 1.0)
  }

  @Test
  fun test11_clutchDisengagedRejection() {
    // Requisito 13: Passagem com embreagem acionada é invalidada/marcada
    val gpsFixes = listOf(
      GpsFixPoint(elapsedRealtimeNanos = 1_000_000_000L, speedMps = 10.0f, hasSpeed = true),
      GpsFixPoint(elapsedRealtimeNanos = 2_000_000_000L, speedMps = 15.0f, hasSpeed = true)
    )
    val sensorSamples = (0..20).map { i ->
      RawSensorSample(
        timestampNs = 1_000_000_000L + i * 50_000_000L,
        rawSensorAccelerationMps2 = 1.0f,
        filteredSensorAccelerationMps2 = 1.0f,
        isValid = true
      )
    }

    val summary = GpsSensorFusionEngine.processFullRun(
      gpsFixes = gpsFixes,
      sensorSamples = sensorSamples,
      params = standardParams,
      hasClutchDisengaged = true
    )

    assertEquals("PASSAGEM INCOMPLETA", summary.runQuality)
    assertNotNull(summary.invalidationReason)
  }

  @Test
  fun test12_gearShiftRejection() {
    // Requisito 13: Troca de marcha durante medição
    val gpsFixes = listOf(
      GpsFixPoint(elapsedRealtimeNanos = 1_000_000_000L, speedMps = 10.0f, hasSpeed = true),
      GpsFixPoint(elapsedRealtimeNanos = 2_000_000_000L, speedMps = 15.0f, hasSpeed = true)
    )
    val sensorSamples = (0..20).map { i ->
      RawSensorSample(
        timestampNs = 1_000_000_000L + i * 50_000_000L,
        rawSensorAccelerationMps2 = 1.0f,
        filteredSensorAccelerationMps2 = 1.0f,
        isValid = true
      )
    }

    val summary = GpsSensorFusionEngine.processFullRun(
      gpsFixes = gpsFixes,
      sensorSamples = sensorSamples,
      params = standardParams,
      hasGearShift = true
    )

    assertEquals("PASSAGEM INCOMPLETA", summary.runQuality)
  }

  @Test
  fun test13_passagemA_vs_passagemB_repeatability() {
    // Requisito Crítico do Usuário:
    // Passagem A: 44.1 -> 78.4 km/h em 10.02s (deltaV = 9.528 m/s, a_media = 0.951 m/s² = 0.097 G)
    // Passagem B: 44.7 -> 77.4 km/h em 9.98s (deltaV = 9.083 m/s, a_media = 0.910 m/s² = 0.093 G)
    // No app legado, na passagem B o acelerômetro mediu 0.17 G bruto (+83% de erro) causando 28% de erro na potência (140.5 cv vs 109.5 cv).
    // Com o GpsSensorFusionEngine, a aceleração é rigorosamente ancorada no GPS e a potência deve concordar em menos de 8%!

    val params = VehiclePhysicsParams(
      totalMassKg = 1344f,
      cd = 0.32f,
      frontalAreaM2 = 2.15f,
      airDensityKgM3 = 1.225f,
      crr = 0.015f,
      drivetrainLossPercent = 12f,
      tireCircumferenceM = 1.98,
      gearRatio = 2.14f,
      finalDrive = 4.10f,
      slopePercent = 0f
    )

    // SIMULAÇÃO PASSAGEM A (10 GPS fixes de 1s cada, total 10.02s)
    val vStartA = 44.1f / 3.6f // 12.25 m/s
    val vEndA = 78.4f / 3.6f   // 21.78 m/s
    val gpsFixesA = (0..10).map { i ->
      val progress = i / 10.0f
      val tNs = (i * 1.002f * 1_000_000_000L).toLong()
      val speed = vStartA + progress * (vEndA - vStartA)
      GpsFixPoint(elapsedRealtimeNanos = tNs, speedMps = speed, hasSpeed = true)
    }
    // Sensor na Passagem A medindo ~0.13 G com ruído
    val sensorA = (0..200).map { i ->
      val tNs = (i * 0.0501f * 1_000_000_000L).toLong()
      RawSensorSample(
        timestampNs = tNs,
        rawSensorAccelerationMps2 = 0.13f * 9.80665f,
        filteredSensorAccelerationMps2 = 0.13f * 9.80665f,
        isValid = true
      )
    }

    val summaryA = GpsSensorFusionEngine.processFullRun(gpsFixesA, sensorA, params)

    // SIMULAÇÃO PASSAGEM B (10 GPS fixes de 1s cada, total 9.98s)
    val vStartB = 44.7f / 3.6f // 12.42 m/s
    val vEndB = 77.4f / 3.6f   // 21.50 m/s
    val gpsFixesB = (0..10).map { i ->
      val progress = i / 10.0f
      val tNs = (i * 0.998f * 1_000_000_000L).toLong()
      val speed = vStartB + progress * (vEndB - vStartB)
      GpsFixPoint(elapsedRealtimeNanos = tNs, speedMps = speed, hasSpeed = true)
    }
    // Sensor na Passagem B medindo 0.17 G (celular com ângulo incorreto / vibração)
    val sensorB = (0..200).map { i ->
      val tNs = (i * 0.0499f * 1_000_000_000L).toLong()
      RawSensorSample(
        timestampNs = tNs,
        rawSensorAccelerationMps2 = 0.17f * 9.80665f, // Sensor distorcido
        filteredSensorAccelerationMps2 = 0.17f * 9.80665f,
        isValid = true
      )
    }

    val summaryB = GpsSensorFusionEngine.processFullRun(gpsFixesB, sensorB, params)

    // VERIFICAÇÕES:
    // 1. G corrigido médio em A e B devem ser próximos do GPS real (~0.097 G e ~0.093 G)
    assertEquals(0.097, summaryA.correctedLongitudinalG.toDouble(), 0.01)
    assertEquals(0.093, summaryB.correctedLongitudinalG.toDouble(), 0.01)

    // 2. G corrigido médio NÃO pode ser 0.17 G
    assertTrue("G corrigido em B não pode ser 0.17 G, obtido: ${summaryB.correctedLongitudinalG}", summaryB.correctedLongitudinalG < 0.11f)

    // 3. A variação de potência entre as passagens A e B deve ser inferior a 8% (antes era 28%!)
    val powerDiffPercent = abs(summaryA.robustPeakPowerCv - summaryB.robustPeakPowerCv) / summaryA.robustPeakPowerCv * 100f
    assertTrue("Diferença de potência deve ser < 8%, obtido: $powerDiffPercent%", powerDiffPercent < 8.0f)

    // 4. Fechamento estrito em ambas as passagens
    assertTrue(abs(summaryA.finalClosureErrorMps) <= 0.02f)
    assertTrue(abs(summaryB.finalClosureErrorMps) <= 0.02f)
  }

  @Test
  fun test14_qualityClassificationGoodRun() {
    // Requisito 15: Classificação "BOA" e margem "±10%" para passagem limpa
    val gpsFixes = (0..10).map { i ->
      GpsFixPoint(
        elapsedRealtimeNanos = i * 1_000_000_000L,
        speedMps = 10f + i * 1.5f,
        hasSpeed = true
      )
    }
    val sensorSamples = (0..200).map { i ->
      RawSensorSample(
        timestampNs = i * 50_000_000L,
        rawSensorAccelerationMps2 = 1.5f,
        filteredSensorAccelerationMps2 = 1.5f,
        isValid = true
      )
    }

    val summary = GpsSensorFusionEngine.processFullRun(gpsFixes, sensorSamples, standardParams)
    assertEquals("BOA", summary.runQuality)
    assertEquals("±10%", summary.marginDisplay)
    assertEquals(10.0, summary.marginPercent.toDouble(), 0.1)
  }

  @Test
  fun test15_qualityClassificationDivergentRun() {
    // Requisito 15: Classificação "GPS/SENSOR DIVERGENTE" quando sensor difere muito do GPS
    val gpsFixes = (0..10).map { i ->
      GpsFixPoint(
        elapsedRealtimeNanos = i * 1_000_000_000L,
        speedMps = 10f + i * 0.8f, // GPS indica deltaV de 8 m/s
        hasSpeed = true
      )
    }
    val sensorSamples = (0..200).map { i ->
      RawSensorSample(
        timestampNs = i * 50_000_000L,
        rawSensorAccelerationMps2 = 2.5f, // Sensor indica deltaV de 25 m/s (>3x GPS!)
        filteredSensorAccelerationMps2 = 2.5f,
        isValid = true
      )
    }

    val summary = GpsSensorFusionEngine.processFullRun(gpsFixes, sensorSamples, standardParams)
    assertEquals("GPS/SENSOR DIVERGENTE", summary.runQuality)
    assertEquals("±20%", summary.marginDisplay)
  }

  @Test
  fun test16_decelerationTailIsExcludedFromDynoWindow() {
    // Reprodução da passada real: 41,5 -> 89,2 km/h, seguida pelos fixes usados
    // apenas para confirmar a desaceleração. O resumo deve encerrar no pico.
    val speedsKmh = listOf(41.5f, 48f, 55f, 63f, 72f, 81f, 89.2f, 76f, 63f, 55.6f)
    val gpsFixes = speedsKmh.mapIndexed { index, speedKmh ->
      GpsFixPoint(
        elapsedRealtimeNanos = index * 1_000_000_000L,
        speedMps = speedKmh / 3.6f,
        hasSpeed = true
      )
    }
    val meanAcceleration = ((89.2f - 41.5f) / 3.6f) / 6f
    val sensorSamples = (0..180).map { index ->
      RawSensorSample(
        timestampNs = index * 50_000_000L,
        rawSensorAccelerationMps2 = meanAcceleration,
        filteredSensorAccelerationMps2 = meanAcceleration,
        isValid = true
      )
    }

    val summary = GpsSensorFusionEngine.processFullRun(gpsFixes, sensorSamples, standardParams)

    assertEquals((89.2f - 41.5f) / 3.6f, summary.totalGpsDeltaVMps, 0.01f)
    assertEquals(6, summary.intervals.size)
    assertEquals(6, summary.intervals.count { it.isAccepted })
    assertEquals(6.0, summary.intervals.sumOf { it.deltaTGpsSec }, 0.001)
    assertTrue(summary.allPoints.all { it.timestampNs <= 6_000_000_000L })
    assertTrue(summary.finalClosureErrorMps <= GpsSensorFusionEngine.CLOSURE_TOLERANCE_MPS)
  }
}
