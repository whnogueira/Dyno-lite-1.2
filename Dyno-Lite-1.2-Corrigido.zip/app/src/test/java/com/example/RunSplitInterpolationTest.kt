package com.example

import com.example.model.RunSplitInterpolation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RunSplitInterpolationTest {
  @Test
  fun speedCrossingIsInterpolatedBetweenGpsFixes() {
    val crossing = RunSplitInterpolation.speedCrossingTimestampNs(
      previousTimestampNs = 5_000_000_000L,
      currentTimestampNs = 6_000_000_000L,
      previousSpeedKmh = 55f,
      currentSpeedKmh = 65f,
      targetSpeedKmh = 60f
    )
    assertEquals(5_500_000_000L, crossing)
  }

  @Test
  fun distanceCrossingUsesMotionInsideGpsInterval() {
    val crossing = RunSplitInterpolation.distanceCrossingTimestampNs(
      previousTimestampNs = 5_000_000_000L,
      currentTimestampNs = 6_000_000_000L,
      previousDistanceM = 90f,
      currentDistanceM = 105f,
      previousSpeedMps = 10f,
      currentSpeedMps = 20f,
      targetDistanceM = 100f
    )
    assertEquals(5_732_050_807L, crossing)
  }

  @Test
  fun noCrossingDoesNotInventSplit() {
    assertNull(
      RunSplitInterpolation.speedCrossingTimestampNs(
        previousTimestampNs = 0L,
        currentTimestampNs = 1_000_000_000L,
        previousSpeedKmh = 50f,
        currentSpeedKmh = 55f,
        targetSpeedKmh = 60f
      )
    )
  }
}
